// عدّلي بيانات الدعوة من هنا فقط
const wedding = {
  groom: "أحمد",
  bride: "سارة",
  dateShort: "٢٠ أكتوبر ٢٠٢٦",
  dateFull: "الثلاثاء، ٢٠ أكتوبر ٢٠٢٦",
  time: "السابعة مساءً",
  venue: "قصر الورد — القاهرة",
  mapUrl: "https://maps.google.com/?q=Cairo"
};

document.getElementById("groomCover").textContent = wedding.groom;
document.getElementById("brideCover").textContent = wedding.bride;
document.getElementById("groomName").textContent = wedding.groom;
document.getElementById("brideName").textContent = wedding.bride;
document.getElementById("coverDate").textContent = wedding.dateShort;
document.getElementById("eventDate").textContent = wedding.dateFull;
document.getElementById("eventTime").textContent = wedding.time;
document.getElementById("venue").textContent = wedding.venue;
document.getElementById("mapLink").href = wedding.mapUrl;

const openButton = document.getElementById("openInvitation");
const details = document.getElementById("details");
openButton.addEventListener("click", () => {
  details.classList.remove("hidden");
  details.setAttribute("aria-hidden", "false");
  requestAnimationFrame(() => details.classList.add("opened"));
  openButton.textContent = "تم فتح الدعوة ✦";
  openButton.disabled = true;
  setTimeout(() => details.scrollIntoView({ behavior: "smooth", block: "start" }), 100);
});

const audio = document.getElementById("waltz");
const musicToggle = document.getElementById("musicToggle");
const musicLabel = document.getElementById("musicLabel");

musicToggle.addEventListener("click", async () => {
  if (audio.paused) {
    try {
      await audio.play();
      musicToggle.classList.add("playing");
      musicLabel.textContent = "إيقاف الموسيقى";
      musicToggle.setAttribute("aria-label", "إيقاف الموسيقى");
    } catch (error) {
      musicLabel.textContent = "أضيفي ملف الموسيقى";
      alert("ضعي ملف فالس بصيغة MP3 باسم waltz.mp3 داخل مجلد assets، ثم ارفعي الملفات إلى GitHub Pages.");
    }
  } else {
    audio.pause();
    musicToggle.classList.remove("playing");
    musicLabel.textContent = "تشغيل الموسيقى";
    musicToggle.setAttribute("aria-label", "تشغيل الموسيقى");
  }
});
